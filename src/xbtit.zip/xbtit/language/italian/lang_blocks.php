<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["BLOCK_USER"]="Informazioni Utente";
$language["BLOCK_INFO"]="Informazioni Tracker";
$language["BLOCK_MENU"]="Menu Principale";
$language["BLOCK_CLOCK"]="Orologio";
$language["BLOCK_FORUM"]="Forum";
$language["BLOCK_LASTMEMBER"]="Ultimo Utente";
$language["BLOCK_ONLINE"]="In Linea";
$language["BLOCK_SHOUTBOX"]="Shout Box";
$language["BLOCK_TOPTORRENTS"]="Top Torrent";
$language["BLOCK_LASTTORRENTS"]="Ultimo Upload";
$language["BLOCK_NEWS"]="Ultime News";
$language["BLOCK_SERVERLOAD"]="Carico Server";
$language["BLOCK_POLL"]="Sondaggi";
$language["BLOCK_SEEDWANTED"]="Ricettori Ricercati per Torrent";
$language["BLOCK_PAYPAL"]="Supportaci";
$language["BLOCK_MAINTRACKERTOOLBAR"]="Barra principale del Tracker";
$language["BLOCK_MAINUSERTOOLBAR"]="Barra principale utenti";
$language["WELCOME_LASTUSER"]=" Benvenuto nel Tracker ";
$language["BLOCK_MINCLASSVIEW"]="Classe minima per vedere";
$language["BLOCK_MAXCLASSVIEW"]="Classe massima per vedere";
?>