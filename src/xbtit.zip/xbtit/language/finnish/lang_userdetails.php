<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["USERNAME"]           = "K&auml;ytt&auml;j&auml;nimi";
$language["EMAIL"]              = "S&auml;hk&ouml;postiosoite";
$language["LAST_IP"]            = "Viimeisin IP";
$language["USER_LEVEL"]         = "K&auml;ytt&auml;j&auml;luokka";
$language["USER_JOINED"]        = "Liittynyt";
$language["USER_LASTACCESS"]    = "Viimeksi n&auml;hty";
$language["PEER_COUNTRY"]       = "Maa";
$language["USER_LOCAL_TIME"]    = "K&auml;ytt&auml;j&auml;n paikallinen aika";
$language["DOWNLOADED"]         = "Ladattu";
$language["UPLOADED"]           = "L&auml;hetetty";
$language["RATIO"]              = "Jakosuhde";
$language["FORUM"]              = "Foorumi";
$language["POSTS"]              = "Postaukset";
$language["POSTS_PER_DAY"]      = "%s Postausta p&auml;iv&auml;ss&auml;";
$language["TORRENTS"]           = "Torrentit";
$language["FILE"]               = "Tiedosto";
$language["ADDED"]              = "Lis&auml;tty";
$language["SIZE"]               = "Koko";
$language["SHORT_S"]            = "L&auml;h";
$language["SHORT_L"]            = "Lat";
$language["SHORT_C"]            = "Val";
$language["NO_TORR_UP_USER"]    = "K&auml;ytt&auml;j&auml; ei ole l&auml;hett&auml;nyt yht&auml;&auml;n torrenttia!";
$language["ACTIVE_TORRENT"]     = "Aktiiviset torrentit";
$language["PEER_STATUS"]        = "Tila";
$language["NO_ACTIVE_TORR"]     = "Ei aktiivisia torrentteja";
$language["PEER_CLIENT"]        = "Clientti";
$language["EDIT"]               = "Muokkaa";
$language["DELETE"]             = "Poista";
$language["PM"]                 = "PM";
$language["BACK"]               = "Takaisin";
$language["NO_HISTORY"]         = "Ei n&auml;ytett&auml;v&auml;&auml; historiaa...";
?>