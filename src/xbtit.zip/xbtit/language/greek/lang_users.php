<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Βρές χρήστη";
$language["USER_LEVEL"]      = "Επίπεδο χρήστη";
$language["ALL"]             = "Όλα";
$language["SEARCH"]          = "Ψάξε";
$language["USER_NAME"]       = "Όνομα χρήστη";
$language["USER_LEVEL"]      = "Επίπεδο χρήστη";
$language["USER_JOINED"]     = "Εντάχθηκε στις";
$language["USER_LASTACCESS"] = "Τελευταία είσοδος";
$language["USER_COUNTRY"]    = "Χώρα";
$language["RATIO"]           = "Αναλογία";
$language["USERS_PM"]        = "Προσωπικά μηνύματα";
$language["EDIT"]            = "Επεξεργασία";
$language["DELETE"]          = "Διαγραφή";
$language["NO_USERS_FOUND"]  = "Δεν βρέθηκαν χρήστες!";
$language["UNKNOWN"]         = "Άγνωστο";

?>