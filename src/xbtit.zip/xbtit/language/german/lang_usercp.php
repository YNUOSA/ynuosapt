<?php
$language["DELETE_READED"]="Löschen";
$language["USER_LANGUE"]="Sprache";
$language["USER_STYLE"]="Aussehen";
$language["CURRENTLY_PEER"]="Du bist zurzeit am Seeden/Leechen von Torrents.";
$language["STOP_PEER"]="Du must deinen Client anhalten.";
$language["USER_PWD_AGAIN"]="Wiederhole Passwort";
$language["EMAIL_FAILED"]="Versand von Email misslang!";
$language["NO_SUBJECT"]="Kein Objekt";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Zum ändern Deiner Einstellungen musst Du dein Passwort eingeben.</strong></font>";
$language["ERR_PASS_WRONG"]="Falsches oder kein Passwort, kann Profil nicht ändern.";
$language["MSG_DEL_ALL_PM"]="Ungelesene PM's werden nicht gelöscht";
$language["ERR_PM_GUEST"]="Tschuldigung, Du kannst Dir oder einem Gast keine PM's schicken!";
?>