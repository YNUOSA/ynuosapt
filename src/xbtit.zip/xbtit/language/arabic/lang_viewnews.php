<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'الكاتب';
$language['POSTED_DATE'] = 'التاريخ';
$language['TITLE']       = 'العنوان';
$language['ADD']         = 'اضف';

?>
