<?php
$language["ACCOUNT_CREATED"]="Account Aangemaakt";
$language["USER_NAME"]="Gebruiker";
$language["USER_PWD_AGAIN"]="Herhaal wachtwoord";
$language["USER_PWD"]="Wachtwoord";
$language["USER_STYLE"]="Style";
$language["USER_LANGUE"]="Taal";
$language["IMAGE_CODE"]="Code Afbeelding";
$language["INSERT_USERNAME"]="U moet een gebruikersnaam opgeven!";
$language["INSERT_PASSWORD"]="U moet een wachtwoord opgeven!";
$language["DIF_PASSWORDS"]="De wachtwoorden komen niet overeen!";
$language["ERR_NO_EMAIL"]="U moet een geldig email adres opgeven";
$language["USER_EMAIL_AGAIN"]="Herhaal email";
$language["ERR_NO_EMAIL_AGAIN"]="Herhaal email";
$language["DIF_EMAIL"]="De email adressen komen niet overeen!";
$language["SECURITY_CODE"]="Beantwoord de vraag";
# Password strength
$language["WEEK"]="Zwak";
$language["MEDIUM"]="Normaal";
$language["SAFE"]="Veilig";
$language["STRONG"]="Sterk";

?>