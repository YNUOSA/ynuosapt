<?php
$language["ERR_NO_TITLE"]="Morate unjeti naziv vijesti";
?>