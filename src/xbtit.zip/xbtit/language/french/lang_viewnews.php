<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Posté par";
$language["POSTED_DATE"] = "Posté le";
$language["TITLE"]       = "Titre";
$language["ADD"]         = "Ajouter";

?>
