<?php
$language['ERR_NO_TITLE']='Trebuie să specifici un Titlu pentru Ştirea ta!';
?>