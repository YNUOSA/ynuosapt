<?php
//中文翻译:ziggear 
//你可以自由修改和发布，但不要删除注释和作者信息。
$language['DELETE_READED']='删除';
$language['USER_LANGUE']='语言选择';
$language['USER_STYLE']='默认风格';
$language['CURRENTLY_PEER']='当前你在做种或下载种子.';
$language['STOP_PEER']='你必须关闭你的客户端.';
$language['USER_PWD_AGAIN']='重复密码';
$language['EMAIL_FAILED']='发送email失败!';
$language['NO_SUBJECT']='没有项目';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>你必须输入密码来完成用户资料的更新.</strong></font>';
$language['ERR_PASS_WRONG']='密码为空或密码错误, 无法更新用户资料.';
$language['MSG_DEL_ALL_PM']='你选择了未读站内信, 他们将会在你读之前被删除';
$language['ERR_PM_GUEST']='对不起你不能给访客或你自己发站内信!';
?>