<?php
$language['ERR_NO_EMAIL']='Trebuie să specifici o adresă de e-mail!';
$language['ERR_INV_EMAIL']='Adresa de e-mail introdusă trebuie sa fie validă!';
$language['ERR_NO_CAPTCHA']='Trebuie sa introduci Codul din Imagine';
$language['IMAGE_CODE']='Cod Imagine';
?>