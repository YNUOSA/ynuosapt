<?php
$language['PEER_PROGRESS']='Progres';
$language['PEER_COUNTRY']='Ţară';
$language['PEER_PORT']='Port';
$language['PEER_STATUS']='Status';
$language['PEER_CLIENT']='Client';
$language['NO_HISTORY']='Nu există istorie';
?>