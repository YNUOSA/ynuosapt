<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Erstellt von";
$language["POSTED_DATE"] = "Erstelldatum";
$language["TITLE"]       = "Titel";
$language["ADD"]         = "Anhängen";

?>