<?php
//中文翻译:ziggear 
//你可以自由修改和发布，但不要删除注释和作者信息。
$language['INSERT_USERNAME']='用户名不能为空!';
$language['INSERT_PASSWORD']='密码不能为空!';
?>