<?php
$language["DELETE_READED"]="Διαγραφή";
$language["USER_LANGUE"]="Γλώσσα";
$language["USER_STYLE"]="Στυλ";
$language["CURRENTLY_PEER"]="Τώρα κάνεις seeding ή leeching κάποιο torrent.";
$language["STOP_PEER"]="Πρέπει να σταματήσεις τον client.";
$language["USER_PWD_AGAIN"]="Επανάληψη κωδικού";
$language["EMAIL_FAILED"]="Η αποστολή του email απέτυχε!";
$language["NO_SUBJECT"]="Δεν υπάρχει θέμα";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Πρέπει να βάλεις των κωδικό σου για να αλλάξεις τις παραπάνω επιλογές.</strong></font>";
$language["ERR_PASS_WRONG"]="Κωδικός κενός ή λανθασμένος, δεν γίνεται αναβάθμιση του προφίλ.";
$language["MSG_DEL_ALL_PM"]="Εαν επιλέξεις προσωπικά μηνύματα που δεν έχουν διαβαστεί, δεν θα διαγραφούν";
$language["ERR_PM_GUEST"]="Συγνώμη δεν μπορείς να στείλεις προσωπικό μήνυμα σε καλεσμένο ή στον εαυτό σου!";
?>