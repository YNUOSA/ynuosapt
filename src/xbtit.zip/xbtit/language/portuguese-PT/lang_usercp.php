<?php
$language["DELETE_READED"]="Apagar";
$language["USER_LANGUE"]="Idioma";
$language["USER_STYLE"]="Estilo";
$language["CURRENTLY_PEER"]="Actualmente estás a receber ou a semear torrents.";
$language["STOP_PEER"]="Deves parar o teu cliente.";
$language["USER_PWD_AGAIN"]="Repetir a senha";
$language["EMAIL_FAILED"]="O envio do e-mail falhou.";
$language["NO_SUBJECT"]="Sem assunto";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>É necessário digitares a tua senha para alterar as configurações acima.</strong></font>";
$language["ERR_PASS_WRONG"]="Senha incorrecta ou vazia, impossivel actualizar perfil.";
$language["MSG_DEL_ALL_PM"]="Se seleccionares PMs que não foram lidas, estas não serão apagadas";
$language["ERR_PM_GUEST"]="Não podes enviar PM a um guest ou para ti mesmo.";
?>