<?php
$language['DELETE_READED']='Şterge';
$language['USER_LANGUE']='Limba';
$language['USER_STYLE']='Skin';
$language['CURRENTLY_PEER']='La momentul actual ai un torrent la leech sau seed.';
$language['STOP_PEER']='Trebuie să-ţi opreşti clientul.';
$language['USER_PWD_AGAIN']='Repetă parola';
$language['EMAIL_FAILED']='Expedierea mesajului e-mail a eşuat!';
$language['NO_SUBJECT']='Nici un subiect';
?>
