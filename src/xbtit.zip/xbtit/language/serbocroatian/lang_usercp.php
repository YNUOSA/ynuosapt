<?php
$language["DELETE_READED"]="Obrisi";
$language["USER_LANGUE"]="Jezik";
$language["USER_STYLE"]="Stil";
$language["CURRENTLY_PEER"]="Trenutno ste aktivni na trackeru (seed/leech).";
$language["STOP_PEER"]="Zaustavite vas klijent.";
$language["USER_PWD_AGAIN"]="Repeat password";
$language["EMAIL_FAILED"]="Greska u slanju e-maila!";
$language["NO_SUBJECT"]="Bez subjekta";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Morate unjeti lozinku za promjenu detalja iznad.</strong></font>";
$language["ERR_PASS_WRONG"]="Lozinka je prazna ili netacna, ne mozemo izmijeniti profil.";
$language["MSG_DEL_ALL_PM"]="Ukoliko odaberete Privatne Poruke koje nisu procitane, one ce takodje biti obrisane";
$language["ERR_PM_GUEST"]="Oprostite, ne mozete poslati poruku Gostu ili sami sebi!";
?>