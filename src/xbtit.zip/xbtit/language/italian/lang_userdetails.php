<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["USERNAME"]           = "Nome Utente";
$language["EMAIL"]              = "Email";
$language["LAST_IP"]            = "Ultimo Ip";
$language["USER_LEVEL"]         = "Grado";
$language["USER_JOINED"]        = "Utente in Linea";
$language["USER_LASTACCESS"]    = "Ultimo Accesso";
$language["PEER_COUNTRY"]       = "Stato";
$language["USER_LOCAL_TIME"]    = "Ora Locale Utente";
$language["DOWNLOADED"]         = "Scaricato";
$language["UPLOADED"]           = "Inviato";
$language["RATIO"]              = "Punteggio";
$language["FORUM"]              = "Forum";
$language["POSTS"]              = "Messaggi";
$language["POSTS_PER_DAY"]      = "Messaggi al giorno";
$language["TORRENTS"]           = "Torrent";
$language["FILE"]               = "File";
$language["ADDED"]              = "Aggiunti";
$language["SIZE"]               = "Dimensione";
$language["SHORT_S"]            = "D";
$language["SHORT_L"]            = "R";
$language["SHORT_C"]            = "C";
$language["NO_TORR_UP_USER"]    = "L'utente non ha ancora inviato nessun torrent!";
$language["ACTIVE_TORRENT"]     = "Torrent Attivi";
$language["PEER_STATUS"]        = "Stato";
$language["NO_ACTIVE_TORR"]     = "Nessun Torrent Attivo...";
$language["PEER_CLIENT"]        = "Client";
$language["EDIT"]               = "Modifica";
$language["DELETE"]             = "Elimina";
$language["PM"]                 = "PM";
$language["BACK"]               = "Indietro";
$language["NO_HISTORY"]         = "Nessuna cronologia da visualizzare...";
?>