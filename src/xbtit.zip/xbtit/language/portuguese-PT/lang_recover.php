<?php
$language["ERR_NO_EMAIL"]="Tens de fornecer um endereço de e-mail";
$language["ERR_INV_EMAIL"]="É preciso digitar um endereço de e-mail válido";
$language["ERR_NO_CAPTCHA"]="É necessário digitar o código da imagem";
$language["IMAGE_CODE"]="código da imagem";
$language["SECURITY_CODE"]="Responde à pergunta";
$language["RECOVER_EMAIL_1"]="\nAlguém, esperamos que tu, solicitou que a senha da conta associada a este endereço de e-mail (%s) fosse redefinida.\n\nO pedido é originário de %s.\n\nSe não efectuaste este pedido, ignora este e-mail e não respondas.\n\nSe desejares confirmar este pedido, segue este link:\n\n%s\n\n	Depois de o teres feito, a tua senha será reiniciada e enviada de volta para ti.\n--\n%s";
$language["RECOVER_EMAIL_2"]="\nDe acordo com o teu pedido, foi gerada uma nova senha para a tua conta.\n\nestes são os novos dados desta conta:\n\n    Nome de Utilizador: %s\n    Senha: %s\n\nPode entrar em %s\n\n--\n%s";
?>