<?php
$language['ACCOUNT_CREATED']='নিবন্ধন সফল হয়েছে';
$language['USER_NAME']='ব্যাবহারকারির নাম';
$language['USER_PWD_AGAIN']='পুনরায় গোপন কোড';
$language['USER_PWD']='গোপন কোড';
$language['USER_STYLE']='দেখার ধরন';
$language['USER_LANGUE']='ভাষা';
$language['IMAGE_CODE']='ছবির নাম্বার';
$language['INSERT_USERNAME']='আপনার নাম অবশ্যই দিতে হবে!';
$language['INSERT_PASSWORD']='আপনার গোপন কোড!';
$language['DIF_PASSWORDS']='কোড don&rsquo;t match হয় না!';
$language['ERR_NO_EMAIL']='আপনার সচল ইমেইল ঠিকানা প্রবেশ করা';
$language['USER_EMAIL_AGAIN']='ইমেইল পুনায় প্রবেশ';
$language['ERR_NO_EMAIL_AGAIN']='ইমেইল পুনায় প্রবেশ';
$language['DIF_EMAIL']='ইমেইল ঠিকানা don&rsquo;t match হয় না!';
$language['SECURITY_CODE']='প্রশ্নের উত্তর লিখুন';
# Password strength
$language['WEEK']='দুর্বল';
$language['MEDIUM']='মধ্যম';
$language['SAFE']='নিরাপদ';
$language['STRONG']='শক্তিশালী';
$language["ERR_GENERIC"]='Generic Error: '.((is_object($GLOBALS['conn'])) ? mysqli_error($GLOBALS['conn']) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));
?>