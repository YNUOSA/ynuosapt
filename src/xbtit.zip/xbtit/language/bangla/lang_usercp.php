<?php
$language['DELETE_READED']='মুছেফেলো';
$language['USER_LANGUE']='ভাষা';
$language['USER_STYLE']='দেখার ধরন';
$language['CURRENTLY_PEER']='You&rsquo;re currently seeding or leeching some torrent.';
$language['STOP_PEER']='You must stop your client.';
$language['USER_PWD_AGAIN']='গোপন কোড আবার আবার লিখুন';
$language['EMAIL_FAILED']='চিঠি যায়নি!';
$language['NO_SUBJECT']='বিষয় ছাড়া';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>আপনার গোপন কোড ছাড়া কোন পরিবর্তন সম্ভব না.</strong></font>';
$language['ERR_PASS_WRONG']='গোপন কোড মেলেনি তাই পরিবর্তন করা সম্ভব না,দুঃখিত.';
$language['MSG_DEL_ALL_PM']='যে চিঠি গুলো আপনি পাঠিয়েছেন কিন্তু পড়া হয়নি সেগুল মুছে ফেলা যাবে না';
$language['ERR_PM_GUEST']='নিজকে নিইজে চিঠি আথবা বা অতিথি চিঠি দাওয়া যাবে না!';
?>