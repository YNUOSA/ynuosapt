<?php
$language["ACCOUNT_CREATED"]="Ο λογαριασμός σας δημιουργήθηκε";
$language["USER_NAME"]="Όνομα χρήστη";
$language["USER_PWD_AGAIN"]="Επανάληψη Κωδικού χρήστη";
$language["USER_PWD"]="Κωδικός χρήστη";
$language["USER_STYLE"]="Στύλ χρήστη";
$language["USER_LANGUE"]="Γλώσσα χρήστη";
$language["IMAGE_CODE"]="Κωδικός εικόνας";
$language["INSERT_USERNAME"]="Πρέπει να γράψεις το όνομα χρήστη!";
$language["INSERT_PASSWORD"]="Πρέπει να γράψεις τον κωδικό!";
$language["DIF_PASSWORDS"]="Ο κωδικός δεν είναι σωστός!";
$language["ERR_NO_EMAIL"]="Πρέπει να γράψεις ενα σωστό ηλεκτρονικό ταχυδρομείο";
$language["USER_EMAIL_AGAIN"]="Επανάληψη ηλεκτρονικού ταχυδρομείου χρήστη";
$language["ERR_NO_EMAIL_AGAIN"]="Επανάληψη ηλεκτρονικού ταχυδρομείου";
$language["DIF_EMAIL"]="Το ηλεκτρονικό ταχυδρομείο δεν υπάρχει!";
$language["SECURITY_CODE"]="Απάντησε στην ερώτηση";
# Κωδικός ισχυρός
$language["WEEK"]="Αδύναμος";
$language["MEDIUM"]="Μεσαίος";
$language["SAFE"]="Ασφαλής";
$language["STRONG"]="Ισχυρός";

?>