<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language['POSTED_BY']   = 'Posted af';
$language['POSTED_DATE'] = 'Dato posted';
$language['TITLE']       = 'Titel';
$language['ADD']         = 'Tilføj';

?>
