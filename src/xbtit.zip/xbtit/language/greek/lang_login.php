<?php
$language["INSERT_USERNAME"]="Γράψε το όνομα χρήστη!";
$language["INSERT_PASSWORD"]="Γράψε τον κωδικό!";
?>