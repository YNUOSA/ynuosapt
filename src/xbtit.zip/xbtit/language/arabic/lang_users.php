<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'ايجاد مستخدم';
$language['USER_LEVEL']      = 'مستوى المستخدم';
$language['ALL']             = 'الكل';
$language['SEARCH']          = 'ابحث';
$language['USER_NAME']       = 'اسم المستخدم';
$language['USER_LEVEL']      = 'مستوى المستخدم';
$language['USER_JOINED']     = 'سجل في';
$language['USER_LASTACCESS'] = 'آخر تواجد';
$language['USER_COUNTRY']    = 'الدولة';
$language['RATIO']           = 'النسبه';
$language['USERS_PM']        = 'رخ';
$language['EDIT']            = 'تعديل';
$language['DELETE']          = 'الغاء';
$language['NO_USERS_FOUND']  = 'لم يتم ايجاد اي اعضاء';
$language['UNKNOWN']         = 'غير معروف';

?>