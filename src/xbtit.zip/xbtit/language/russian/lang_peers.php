<?php
$language["PEER_PROGRESS"]="Прогресс";
$language["PEER_COUNTRY"]="Страна";
$language["PEER_PORT"]="Порт";
$language["PEER_STATUS"]="Статус";
$language["PEER_CLIENT"]="Клиент";
$language["NO_PEERS"]="Пиров нет";
?>