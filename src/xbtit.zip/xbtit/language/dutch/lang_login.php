<?php
$language["INSERT_USERNAME"]="U moet een gebruikersnaam opgeven!";
$language["INSERT_PASSWORD"]="U moet een wachtwoord opgeven!";
?>