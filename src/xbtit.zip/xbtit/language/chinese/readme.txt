请在支持UTF-8的环境下使用。

如果遇到不能切换中文的情况，请使用Mint主题，设置成Chinese-Simplified
然后关闭浏览器，清除缓存，再切换回default主题。

其他问题请联系
 ziggear@gmail.com