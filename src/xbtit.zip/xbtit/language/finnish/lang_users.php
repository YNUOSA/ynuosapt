<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Etsi k&auml;ytt&auml;j&auml;";
$language["USER_LEVEL"]      = "K&auml;ytt&auml;j&auml;luokka";
$language["ALL"]             = "Kaikki";
$language["SEARCH"]          = "Etsi";
$language["USER_NAME"]       = "K&auml;ytt&auml;j&auml;nimi";
$language["USER_LEVEL"]      = "K&auml;ytt&auml;j&auml;luokka";
$language["USER_JOINED"]     = "Liittynyt";
$language["USER_LASTACCESS"] = "Viimeksi n&auml;hty";
$language["USER_COUNTRY"]    = "Maa";
$language["RATIO"]           = "Jakosuhde";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Muokkaa";
$language["DELETE"]          = "Poista";
$language["NO_USERS_FOUND"]  = "K&auml;ytt&auml;ji&auml; ei l&ouml;ytynyt!";
$language["UNKNOWN"]         = "Tuntematon";

?>