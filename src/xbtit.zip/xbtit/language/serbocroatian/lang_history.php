<?php
$language["PEER_PROGRESS"]="Progres";
$language["PEER_COUNTRY"]="Zemlja";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="KliJent";
$language["NO_HISTORY"]="Istorija je trenutno prazna";
?>