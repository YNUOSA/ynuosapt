<?php

// ENGLISH USERS.PHP FILE

$language['FIND_USER']       = 'Find bruger';
$language['USER_LEVEL']      = 'Bruger niveau';
$language['ALL']             = 'Alle';
$language['SEARCH']          = 'Søg';
$language['USER_NAME']       = 'Brugernavn';
$language['USER_LEVEL']      = 'Bruger niveau';
$language['USER_JOINED']     = 'Kom til';
$language['USER_LASTACCESS'] = 'Sidste login';
$language['USER_COUNTRY']    = 'Land';
$language['RATIO']           = 'Ratio';
$language['USERS_PM']        = 'Besked';
$language['EDIT']            = 'Rediger';
$language['DELETE']          = 'Slet';
$language['NO_USERS_FOUND']  = 'Ingen brugere fundet!';
$language['UNKNOWN']         = 'Ukendt';

?>