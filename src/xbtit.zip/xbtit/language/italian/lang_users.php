<?php

// ITALIAN USERS.PHP FILE

$language["FIND_USER"]       = "Ricerca Utente";
$language["USER_LEVEL"]      = "Livello Utente";
$language["ALL"]             = "Tutto";
$language["SEARCH"]          = "Ricerca";
$language["USER_NAME"]       = "Nome Utente";
$language["USER_LEVEL"]      = "Livello Utente";
$language["USER_JOINED"]     = "Utente In Linea da";
$language["USER_LASTACCESS"] = "Ultimo Accesso";
$language["USER_COUNTRY"]    = "Paese";
$language["RATIO"]           = "Punteggio";
$language["USERS_PM"]        = "PM";
$language["EDIT"]            = "Modifica";
$language["DELETE"]          = "Elimina";
$language["NO_USERS_FOUND"]  = "Nessun Utente Trovato!";
$language["UNKNOWN"]         = "Sconosciuto";

?>