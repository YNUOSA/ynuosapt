<?php

// USERDETAILS.PHP LANGUAGE FILE

$language["MEMBER"]             = "Mitglied";
$language["USERNAME"]           = "Benutzername";
$language["EMAIL"]              = "Email";
$language["LAST_IP"]            = "Letzte Ip";
$language["USER_LEVEL"]         = "Rang";
$language["USER_JOINED"]        = "Eintritt";
$language["USER_LASTACCESS"]    = "Letzter Zugriff";
$language["PEER_COUNTRY"]       = "Land";
$language["USER_LOCAL_TIME"]    = "Benutzer Ortszeit";
$language["DOWNLOADED"]         = "downloaded";
$language["UPLOADED"]           = "uploaded";
$language["RATIO"]              = "Verhältnis";
$language["FORUM"]              = "Forum";
$language["POSTS"]              = "Beiträge";
$language["POSTS_PER_DAY"]      = "%s Beiträge pro Tag";
$language["TORRENTS"]           = "Torrents";
$language["FILE"]               = "Datei";
$language["ADDED"]              = "Hinzugefügt";
$language["SIZE"]               = "Grösse";
$language["SHORT_S"]            = "S";
$language["SHORT_L"]            = "L";
$language["SHORT_C"]            = "C";
$language["NO_TORR_UP_USER"]    = "Benutzer hat noch keinen Torrent hochgeladen!";
$language["ACTIVE_TORRENT"]     = "Aktive Torrents";
$language["PEER_STATUS"]        = "Status";
$language["NO_ACTIVE_TORR"]     = "Nicht aktive Torrents";
$language["PEER_CLIENT"]        = "Client";
$language["EDIT"]               = "Bearbeiten";
$language["DELETE"]             = "Löschen";
$language["PM"]                 = "PM";
$language["BACK"]               = "Zurück";
$language["NO_HISTORY"]         = "Keine Statistik vorhanden...";
?>