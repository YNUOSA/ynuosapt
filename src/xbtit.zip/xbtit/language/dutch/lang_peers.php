<?php
$language["PEER_PROGRESS"]="Voortgang";
$language["PEER_COUNTRY"]="Land";
$language["PEER_PORT"]="Port";
$language["PEER_STATUS"]="Status";
$language["PEER_CLIENT"]="Cli&euml;nt";
$language["NO_PEERS"]="Geen peers";
?>