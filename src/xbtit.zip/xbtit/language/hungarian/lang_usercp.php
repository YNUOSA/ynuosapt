<?php
$language["DELETE_READED"]="Törlés";
$language["USER_LANGUE"]="Nyelv";
$language["USER_STYLE"]="Stílus";
$language["CURRENTLY_PEER"]="Jelenlegi seedelt vagy letöltés alatt levő torrentek.";
$language["STOP_PEER"]="Megállítanád a kliensed és újraindítanád.";
$language["USER_PWD_AGAIN"]="Jelszó újból";
$language["EMAIL_FAILED"]="Nem sikerült az email küldés!";
$language["NO_SUBJECT"]="Nincs megjegyzés";
$language["MUST_ENTER_PASSWORD"]="<br /><font color='#FF0000'><strong>Be kell írnod a jelszavad a változtatások érvényesítéséhez.</strong></font>";
$language["ERR_PASS_WRONG"]="A jelszavad üres, így nem tudom a profilod módosítani.";
$language["MSG_DEL_ALL_PM"]="Az olvasatlan üzeneteket nem lehet törölni! Törlés előtt olvasd el a Privát Üziket";
$language["ERR_PM_GUEST"]="Sajnálom, nem küldhetsz PM-et magadnak vagy Vendég felhasználónak!";
?>