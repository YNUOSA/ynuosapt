<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["NOT_SHA"]="La funzione SHA1 non è disponibile. Hai bisogno di 4.3.0 o superiore.";
$language["NOT_AUTHORIZED_UPLOAD"]="Non sei autorizzato all'upload!";
$language["FILE_UPLOAD_ERROR_1"]="Non posso leggere il file inviato";
$language["FILE_UPLOAD_ERROR_3"]="Il file ha la dimensione uguale a zero";
$language["FACOLTATIVE"]="facoltativo";
$language["FILE_UPLOAD_ERROR_2"]="Errore Invio File";
$language["ERR_PARSER"]="Sembrerebbe che ci sono degli errori nel tuo torrent. Il parser non lo accetta.";
$language["WRITE_CATEGORY"]="Devi specificare la categoria del torrent...";
$language["DOWNLOAD"]="Download";
$language["MSG_UP_SUCCESS"]="Invio fatto correttamente! Il torrent è stato aggiunto con successo.";
$language["MSG_DOWNLOAD_PID"]="Sistema PID attivo, prendi il tuo torrent con il tuo PID";
$language["EMPTY_DESCRIPTION"]="Devi inserire una descrizione!";
$language["EMPTY_ANNOUNCE"]="L'Announce è vuoto";
$language["FILE_UPLOAD_ERROR_1"]="Non posso leggere il file inviato";
$language["FILE_UPLOAD_ERROR_2"]="Errore Invio File";
$language["FILE_UPLOAD_ERROR_3"]="La dimensione del File è zero";
$language["NO_SHA_NO_UP"]="File upload non disponibile - Le funzioni SHA1 non sono disponibili.";$language["ERR_HASH"]="L'Info hash DEVE essere 40 hex byte.";
$language["ERR_EXTERNAL_NOT_ALLOWED"]="Torrent esterni non permessi";
$language["ERR_MOVING_TORR"]="Errore Spostamento torrent...";
$language["ERR_ALREADY_EXIST"]="Questo torrent è già presente nel database.";
?>