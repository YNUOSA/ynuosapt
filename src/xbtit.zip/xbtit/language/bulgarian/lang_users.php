<?php

// ENGLISH USERS.PHP FILE

$language["FIND_USER"]       = "Намери потребител";
$language["USER_LEVEL"]      = "Потребителско ниво";
$language["ALL"]             = "Всички";
$language["SEARCH"]          = "Търсене";
$language["USER_NAME"]       = "Име";
$language["USER_LEVEL"]      = "Потребителско ниво";
$language["USER_JOINED"]     = "Регистриран на";
$language["USER_LASTACCESS"] = "Последен достъп";
$language["USER_COUNTRY"]    = "Държава";
$language["RATIO"]           = "Рейтинг";
$language["USERS_PM"]        = "ЛС";
$language["EDIT"]            = "Редактирай";
$language["DELETE"]          = "Изтрий";
$language["NO_USERS_FOUND"]  = "Няма намерени потребители!";
$language["UNKNOWN"]         = "Непознат";

?>