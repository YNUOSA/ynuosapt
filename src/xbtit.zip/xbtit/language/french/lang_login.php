<?php
$language["INSERT_USERNAME"]="Vous devez saisir un nom d'utilisateur !";
$language["INSERT_PASSWORD"]="Vous devez saisir un mot de passe !";
?>