<?php
$language["PEER_PROGRESS"]="Edistyminen";
$language["PEER_COUNTRY"]="Maa";
$language["PEER_PORT"]="Portti";
$language["PEER_STATUS"]="Tila";
$language["PEER_CLIENT"]="Clientti";
$language["NO_HISTORY"]="Ei n&auml;ytett&auml;v&auml;&auml; historiaa";
?>