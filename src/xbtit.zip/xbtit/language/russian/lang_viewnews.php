<?php

// VIEWNEWS.PHP LANGUAGE FILE

$language["POSTED_BY"]   = "Написано";
$language["POSTED_DATE"] = "Дата поста";
$language["TITLE"]       = "Название";
$language["ADD"]         = "Добавить";

?>
