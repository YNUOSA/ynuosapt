<?php
// Traduzione eseguita da mOOn, con il QCheck di Laurianti.
//Un grazie anche a Confe, e a chi si è prodigato nel testare il Tracker
// Per qualsiasi info ci trovate su http://www.btiteam.org
$language["PEER_PROGRESS"]="Progresso";
$language["PEER_COUNTRY"]="Paese";
$language["PEER_PORT"]="Porta";
$language["PEER_STATUS"]="Stato";
$language["PEER_CLIENT"]="Client";
$language["NO_PEERS"]="Nessun Nodo";
?>