<?php
$language['ACCOUNT_CREATED']='Account Created';
$language['USER_NAME']='User';
$language['USER_PWD_AGAIN']='Repeat password';
$language['USER_PWD']='Password';
$language['USER_STYLE']='Style';
$language['USER_LANGUE']='Language';
$language['IMAGE_CODE']='Image Code';
$language['INSERT_USERNAME']='You must insert a username!';
$language['INSERT_PASSWORD']='You must insert a password!';
$language['DIF_PASSWORDS']='The passwords don&rsquo;t match!';
$language['ERR_NO_EMAIL']='You must enter a valid email address';
$language['USER_EMAIL_AGAIN']='Repeat email';
$language['ERR_NO_EMAIL_AGAIN']='Repeat email';
$language['DIF_EMAIL']='The emails don&rsquo;t match!';
$language['SECURITY_CODE']='Answer the question';
# Password strength
$language['WEEK']='Weak';
$language['MEDIUM']='Medium';
$language['SAFE']='Safe';
$language['STRONG']='Strong';
$language["ERR_GENERIC"]='Generic Error: '.((is_object($GLOBALS['conn'])) ? mysqli_error($GLOBALS['conn']) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));
?>