<?php
$language['PEER_PROGRESS']='Progress';
$language['PEER_COUNTRY']='Country';
$language['PEER_PORT']='Port';
$language['PEER_STATUS']='Status';
$language['PEER_CLIENT']='Client';
$language['NO_HISTORY']='No history to display';
?>