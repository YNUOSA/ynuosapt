<?php
$language['DELETE_READED']='الغاء';
$language['USER_LANGUE']='اللغة';
$language['USER_STYLE']='الشكل';
$language['CURRENTLY_PEER']='انت حاليا تقوم بنثر او استنزاف بعض التورينتات';
$language['STOP_PEER']='عليك ايقاف برنامج التورينت عندك.';
$language['USER_PWD_AGAIN']='كرر كلمة السر';
$language['EMAIL_FAILED']='فشل في ارسالة البريد';
$language['NO_SUBJECT']='بدون عنوان';
$language['MUST_ENTER_PASSWORD']='<br /><font color="#FF0000"><strong>عليك ادخال كلمة السر لتطبيق التغييرات</strong></font>';
$language['ERR_PASS_WRONG']='كلمة السر فاضية او غير صحيحة لهذا لا يمكن تعديل الملف الشخصي';
$language['MSG_DEL_ALL_PM']='اذا اخترت الرسائل الخاصة التي لم تقراء .. لن يتم الغاء تلك الرسائل';
$language['ERR_PM_GUEST']='عذرا.. لا يمكنك ارسال الرسائل الى نفسك او الى الضيوف!';
?>